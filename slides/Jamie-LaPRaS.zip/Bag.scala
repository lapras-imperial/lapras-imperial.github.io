/** A multiset, where every element `A` may appear with some multiplicativity */
type Bag[A] = Map[A, Int]

extension [A] (b1: Bag[A]) {
    def merge(b2: Bag[A]): Bag[A] = b1.foldLeft(b2) { case (b, (k, n)) =>
        b.updatedWith(k)(m => Some(m.getOrElse(0) + n))
    }
}
object Bag {
    def single[A](x: A): Bag[A] = Map(x -> 1)
}
