import scala.quoted.*

/*
We came up with some nice properties with QInt, but it
was quite ad-hoc.

we noticed that we can define individual operations
on static and dynamic values, and sometimes we can
apply some laws. This can have its limits though...
Consider the following QInt expression:

Sta(3) + Sta(3) + Dyn(qx) + Sta(1)

What would we expect the resulting `asExpr` to be?
In the best case, we might expect 7 and qx, but
let's evaluate it by hand and see what we get:

Sta(3).+(Sta(3)).+(Dyn(qx)).+(Sta(1))
=
Sta(3).+(3).+(Dyn(qx)).+(Sta(1))
=
Sta(6).+(Dyn(qx)).+(Sta(1))
=
Dyn(qx).+(3).+(Sta(1))
=
Dyn('{$qx + 3}).+(Sta(1))
=
Dyn('{$qx + 3}).+(1)
=
Dyn('{($qx + 3) + 1}')

As soon as something other than `0` touches a `Dyn` with addition,
that's it, it's dynamic and no longer usable. Dynamic information
is corrupting and contagious like that. It would be nice if we
could leverage commutativity to try and flip round the data to
gather it on one side, but we'd have to be careful with implementing
this!

It is best if we can come up with a representation that automatically
respects our laws.

Ring polynomials are an algebraic structure that does
have laws that correspond to the ones we've been using
for multiplication.
*/

/*
A *term* is something of the form x1^k1*..*xn^kn for some
dynamic values x1 through xn each to the power of some static
constant k1 through kn.

This is represented by a "bag", or multi-set. For example,
the term `x^2y` is represented as `Bag(x -> 2, y -> 1)`.
These exprs are identified by *referential* equality.
*/
type Term = Bag[Expr[Int]]

/*
A *polynomial* is something of the form c + k1*t1 + .. + kn*tn
for some static constant `c`, and terms `t1` through `tn` multiplied
by some static constants `k1` through `kn`.

Again this uses the bag, but this time the multiplicity of the
bag corresponds to the multiplication of the term, not the power.
For instance: `1 + 3x^2 + 5yz` is represented as:
`Poly(1, Bag(Bag(x -> 2) -> 3, Bag(y -> 1, z -> 1) -> 5))`
This outer bag works by using *structural* equality on the term-bags.

As bags are a commutative structure that preserves duplicates,
they are well suited for allowing us to commute static and
dynamic values to keep them separate. Effectively, static values
float into the constant or the multiplicities, and dynamic values
gather in the bottom of the bags. Now, it remains to implement
our familiar API from QInt.
*/
case class Poly private (sta: Int, dyns: Bag[Term]) {
    // STATIC OPERATIONS (no Quotes)
    /*
    The exciting thing about these arithmetic operations
    is that they don't use `Quotes`, like those from QInt.
    That suggests that they are more static, and do not need
    to generate code. This helps us reason that we are keeping
    the static and dynamic things separate, which is good!
    */
    // it is easy to define addition of a constant as such affecting
    // the static component at the end.
    def +(n: Int): Poly = Poly(sta + n, dyns)
    // Addition of two polynomials is much the same, but this time
    // we *merge* the term bags: if a term appears in both bags,
    // the multiplicities will be added such that 3*x + 2*x -> 5*x.
    def +(p: Poly): Poly = Poly(sta + p.sta, dyns.merge(p.dyns))
    // for multiplication by a constant, we just need to distribute
    // the multiplication through every term (distributivity is
    // one of the ring polynomial laws!)
    // (c + x .. + y) * n = c * n + n * x + .. + n * y
    // This can be done by multiplying all the multiplicities in the
    // terms by the constant `n`.
    def *(n: Int): Poly = Poly(sta * n, dyns.view.mapValues(_ * n).toMap)
    // Multiplying two polynomials is absolutely the hardest case.
    // As above, it involves distributivity, except this will push
    // a polynomial down into the terms. Once those are flattened
    // and normalised we can add them all together.
    // To codify this, first take every term in `dyns` of the form,
    // `n * t`, and map it to be `p * t * n` (we will need to define
    // how to multiply a polynomial by a term for this). This gives
    // us a bunch of expanded polynomial terms; then, take the polynomial
    // and multiply it plainly by our constant; finally, sum all these
    // new polynomials together to allow them to normalise and merge
    // (this is achieved with `_ + _` given to foldLeft)
    def *(p: Poly): Poly = dyns.map((t, n) => p * t * n).foldLeft(p * sta)(_ + _)

    // This is the "simpler" case of multiplying a whole
    // polynomial by a single term (with no multiplicity)
    private def *(t: Term): Poly = {
        // first, form a polynomial with just this term in it, then multiply by
        // our static constant
        val staTerm: Poly = Poly(Bag.single(t)) * sta
        // then, for every term of the form `n * t2`, merge the
        // term bags (which will perform merging of x^n*x^m to x^(n+m))
        // and give it multiplicity `n`.
        val dynTerms: Bag[Term] = dyns.map((t2, n) => (t.merge(t2), n))
        // form a polynomial of those new terms, and add the staTerm
        // polynomial to it.
        staTerm + Poly(dynTerms)
    }

    // DYNAMIC OPERATIONS (uses Quotes)
    /*
    Now that we've created a normalising structure, we need to figure
    out how to turn it back into a single piece of code. At the top-level
    we will try and convert the polynomial, which may return `None` (if
    there are no terms, we'll find out), in which case we return our
    static constant term.
    */
    def asExpr(using Quotes): Expr[Int] = fromPoly.getOrElse(Expr(sta))

    // fromTerms(dyns) will convert our terms into a single expression,
    // should they exist. It'll return `None` otherwise. If our static
    // component is 0, we will do nothing, otherwise we will map `+ n`
    // into that term. By mapping this, we can be sure we won't generate
    // any redundancies like `0 + n`, as the addition only occurs if there
    // was a collapsed term, with `n` returned in the function above.
    private def fromPoly(using Quotes): Option[Expr[Int]] = sta match {
        case 0 => fromTerms(dyns)
        case n => fromTerms(dyns).map(e => '{$e + ${Expr(n)}})
    }

    // The function `fromTerm` takes a term of the form n*t and turns it
    // into an expression if it wouldn't be 0. By mapping `fromTerm` over
    // dyns we would get a list of options. To make it nicer to work with,
    // dyns.flatMap(fromTerm(_, _)) will remove any terms that collapse
    // into None (i.e. normalises out `+ 0`). Once we have these terms we
    // can return them using `+`, using reduceOption: this returns None
    // if the list was empty (i.e. all the terms were eliminated).
    private def fromTerms(dyns: Bag[Term])(using Quotes): Option[Expr[Int]] = {
        dyns.flatMap(fromTerm(_, _)).reduceOption { (e1, e2) =>
            '{$e1 + $e2}
        }
    }

    // At this level, we can start using our laws of multiplication.
    // if n was 0, we can drop the term from the representation
    // if n is 1, we don't need to generate a multiplication
    // otherwise, we will (if the term exists) map `* n` over it.
    private def fromTerm(dyn: Term, n: Int)(using Quotes): Option[Expr[Int]] = n match {
        case 0 => None
        case 1 => fromTerm(dyn)
        case n => fromTerm(dyn).map(e => '{$e * ${Expr(n)}})
    }

    // Finally, for every term of the form `n * t`, turn this into
    // a `t^n` using QInt (yay reusable code!). Then as long as there
    // were factors in the term, multiply all the factors together
    // using *.
    private def fromTerm(dyn: Term)(using Quotes): Option[Expr[Int]] = {
        dyn.map((t, n) => QInt.Dyn(t).pow(n).asExpr).reduceOption {
            (e1, e2) => '{$e1 * $e2}
        }
    }

    /*
    And that's it!

    What's cool about this, is that we defined the static operations
    without needing to interact with the code itself, which gives us
    a vague intuition that these operations are working at the right
    level. This was leveraging distributivity to simplify the problems,
    and then using the natural commutativity of bags to normalise
    with respect to that law. Then, asExpr applied the "zero" and "unit"
    laws for addition and multiplication, to remove redundancy as we
    generate the expression (as in `QInt`). This gives a nice interplay
    between the algebraic structure of polynomials and the analysis
    provided by staging.

    While this is a fairly contrived example, hopefully it gives a
    sense of what metaprogramming (in this form "staging") can offer
    us, and the power of leveraging our domain-specific knowledge to
    help the compiler optimise WITH us. No matter what your research
    area, staging has practical impliciations for helping design
    domain-specific compilers without needing to build all of the
    infrastructure of a compiler yourself -- syntax is handled,
    type system is handled, build process and project structure handled;
    all that remains is the interesting domain-specific modelling
    and optimisation.
    */

    def show(using Quotes) = Poly.showExpr(sta, dyns)
}
object Poly {
    // This is yet another helper function for constructing polynomials,
    // similar to `QInt`'s, looking to inspect the static values.
    def apply(n: Int): Poly = Poly(n, Map.empty)
    def apply(e: Expr[Int])(using Quotes): Poly = e.value match
    case None => Poly(Bag.single(Bag.single(e)))
    case Some(n) => Poly(n)

    private def apply(ts: Bag[Term]): Poly = Poly(0, ts)


    // Just to pretty-print things :)
    private def showExpr(sta: Int, dyns: Bag[Term])(using Quotes): String = sta match {
        case 0 => dyns.flatMap(showTerm).mkString(" + ")
        case n => (sta :: dyns.flatMap(showTerm).toList).mkString(" + ")
    }
    private def showTerm(dyns: Term, mult: Int)(using Quotes): Option[String] = mult match {
        case 0 => None
        case 1 => Some(dyns.map((x, n) => s"${x.show}^$n").mkString(" * "))
        case n => Some((mult :: dyns.map((x, n) => s"${x.show}^$n").toList).mkString(" * "))
    }
}
