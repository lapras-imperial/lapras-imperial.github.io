import scala.quoted.*

/** A `QInt` is a representation of *partially-static*
  * data. It allows us to reason about different knownnesses
  * of numeric data in a uniform way with the following
  * interface:
  */
sealed abstract class QInt {
    /** Turn this integer into an AST representation. */
    def asExpr(using Quotes): Expr[Int]
    /** Add two integers, both either static or dynamic. */
    def +(q: QInt)(using Quotes): QInt
    /** Add this integer, which may be static or dynamic, to a static integer */
    def +(n: Int)(using Quotes): QInt
    /** Multiply two integers, both either static or dynamic. */
    def *(q: QInt)(using Quotes): QInt
    /** Multiply this integer, which may be static or dynamic, with a static integer */
    def *(n: Int)(using Quotes): QInt

    /** Take the current value represented by this `QInt`
      * and, if necessary, bind it to a new variable. This
      * is fed to the continuation `k` to produce another
      * `QInt`.
      *
      * @param k what should I do with this new binding?
      */
    def let(k: QInt => Quotes ?=> QInt)(using Quotes): QInt
}


object QInt {
    /** This function can be used to take the code that
      * represents an integer and turns it into the `QInt`.
      * If Scala can determine the value of `qx` statically,
      * it will return a `Sta`, otherwise it is left as `Dyn`.
      */
    def apply(qx: Expr[Int])(using Quotes) = qx.value match {
        case None => Dyn(qx)
        case Some(n) => Sta(n)
    }

    /** A statically known integer, `m`. */
    case class Sta(m: Int) extends QInt {
        // when we turn a static constant back into an Expr
        // Scala can "lift" it for us with `Expr(_)`.
        def asExpr(using Quotes): Expr[Int] = Expr(m)
        // The value `q` may or may not be static, we don't know.
        // what we do know is that we can call `q + m`, with our
        // static constant, which passes our static knowledge
        // forward. This is the classic OOP "double-dispatch" at work.
        def +(q: QInt)(using Quotes): QInt = q + m
        // When we are being added to a static integer, the answer
        // can be statically computed, and the result is also static.
        def +(n: Int)(using Quotes): QInt = Sta(m + n)
        // Both of the following functions are similar to the above
        // counterparts
        def *(q: QInt)(using Quotes): QInt = q * m
        def *(n: Int)(using Quotes): QInt = Sta(m * n)

        // In the static case, we don't need to bind the variable, since
        // function arguments will do it for us, so just pass the value
        // on to `k` without doing anything to it.
        def let(k: QInt => Quotes ?=> QInt)(using Quotes): QInt = k(this)
    }
    /** Represents a dynamic, unknown, integer, `e`. */
    case class Dyn(e: Expr[Int]) extends QInt {
        // `e` is already an expression, easy!
        def asExpr(using Quotes): Expr[Int] = e

        // This time, we are adding something that may or
        // may not be static to us, a dynamic value.
        def +(q: QInt)(using Quotes): QInt = q match {
            // if `q` is statically, known, use the other +, it might help
            case Sta(n) => this + n
            // nothing we can do here, generate a dynamic value and the
            // code that represents the addition
            case Dyn(e2) => Dyn('{$e + $e2})
        }
        // This is perhaps the most interesting case. Here we can use
        // our knowledge about `+` to try and remove a generated addition
        // where possible.
        def +(n: Int)(using Quotes): QInt = n match {
            case 0 => this
            case n => Dyn('{$e + ${Expr(n)}})
        }
        // Again, this proceeds much the same as before
        def *(q: QInt)(using Quotes): QInt = q match {
            case Sta(n) => this * n
            case Dyn(e2) => Dyn('{$e * $e2})
        }
        // Again, here we can make use of our improved
        // static information to try and optimise wrt
        // the laws of multiplication.
        def *(n: Int)(using Quotes): QInt = n match {
            case 0 => Sta(0) // this case is great, we actually turned Dyn * Sta into a Sta!
            case 1 => this
            case n => Dyn('{$e * ${Expr(n)}})
        }

        // This mirrors what we did in powerImpl, where we generate
        // a val, and pass the representation forward. This time, however
        // we need to construct a `Dyn` of `r` and then turn it back into
        // an `Expr` before we splice it in.
        def let(k: QInt => Quotes ?=> QInt)(using Quotes): QInt = Dyn('{
            val r = $e
            ${k(Dyn('r)).asExpr}
        })
    }
}

// Now you can go back to `power.scala` and continue reading :)
