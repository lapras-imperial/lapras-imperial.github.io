{-# LANGUAGE NoImplicitPrelude #-}
module SnocList where

import Prelude hiding ((++), length, repeat, reverse)
import List hiding (match)
import qualified List as L

data SnocList a where 
  Lin  :: SnocList a
  Snoc :: SnocList a -> a -> SnocList a

reverse :: SnocList a -> List a
reverse sx = go sx Nil where
  go :: SnocList a -> List a -> List a
  go Lin xs = xs
  go (Snoc sx x) ys = go sx (Cons x ys)

-- We have now O(1) snoc but
-- `match xs` becomes O(length xs)
match :: SnocList a
      -> b
      -> (a -> SnocList a -> b)
      -> b
match Lin e _         = e
match (Snoc sx x) _ f = match sx 
  (f x Lin)
  (\y ys -> f y (Snoc ys x))
