{-# LANGUAGE NoImplicitPrelude #-}
module List where

import Prelude hiding ((++), length, repeat)
import Time

data List a where
  Nil  :: List a
  Cons :: a -> List a -> List a

-- `null`, `head`, and `tail` are subsumed by `match`
match :: List a
      -> b
      -> (a -> List a -> b)
      -> b
match Nil e _ = e
match (Cons x xs) _ f = f x xs
-- `match` is O(1)

(++) :: List a -> List a -> List a
Nil         ++ ys = ys
(Cons x xs) ++ ys = Cons x (xs ++ ys)
-- `xs ++ ys` is O(length xs)

snoc :: List a -> a -> List a
snoc xs y = xs ++ Cons y Nil

repeat :: Int -> a -> List a
repeat 0 x = Nil
repeat n x = snoc (repeat (n - 1) x)  x

repeat' :: Int -> a -> List a
repeat' 0 x = Nil
repeat' n x = Cons x (repeat' (n - 1) x)

length :: List a -> Int
length xs = match xs
              0 (\_ n -> 1 + length n)

test1 = time $ 
  length (repeat 10000 'a')

test2 = time $
  length (repeat' 10000 'a')
