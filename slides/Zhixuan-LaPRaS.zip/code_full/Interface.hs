class (list :: * -> *)where
  nil :: list
  cons :: a -> list a -> list a
  match :: list a
        -> b  -- if the list is empty
        -> (a -> list a -> b)
              -- if the list has a head
        -> b
  (++) :: list a -> list a -> list a

  snoc :: list a -> a -> list a
  snoc xs y = xs ++ (cons y nil)

  head :: list a -> a
  head xs = match xs (error "louis xvi")
                     (\x _ -> x)

  tail :: list a -> a
  tail xs = match xs (error "louis xvi")
                     (\_ xs -> xs)
