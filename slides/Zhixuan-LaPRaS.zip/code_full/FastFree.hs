{-# LANGUAGE FlexibleInstances, FlexibleContexts, MultiParamTypeClasses, FunctionalDependencies, InstanceSigs #-}
{-# OPTIONS_GHC -Wno-noncanonical-monad-instances #-}

module FastFree where

import Prelude hiding (head, tail, concat)
import Control.Monad

{- We translate
  1. types A to functors F

  2. functions A -> B to polymorphic functions (forall x. F x -> G x)

  3. unit type () to the identity functor

  4. pair type (A, B) to composition F . G or isomorphically
    (F . G) a = exists x. (F x , x -> G a)

By currying and uncurrying, a function 
A -> B -> C will be translated to
  forall x y. F y -> (y -> G x) -> H x
-}



-- Also called the free monad
data ListF sig a where
  Ret  :: a -> ListF sig a
  Cons :: sig a -> (a -> ListF sig b) 
       -> ListF sig b

instance Monad (ListF sig) where
  return :: a -> ListF sig a
  return = Ret

  (>>=) :: ListF sig a -> (a->ListF sig b)
        -> ListF sig b
  (Ret a)     >>= k = k a
  (Cons x xs) >>= k = 
    Cons x (\a -> xs a >>= k)

instance Functor (ListF sig) where
  fmap = liftM

instance Applicative (ListF sig) where
  pure = return
  (<*>) = ap

matchF :: ListF sig x 
       -> (forall x. x -> h x)
       -> (forall x y. sig y ->
             (y -> ListF sig x) -> h x)
       -> h x
matchF (Ret a)     e _ = e a
matchF (Cons x xs) _ f = f x xs

-- Snoc lists
---------------------------

data SnocF sig a where
  Ret' :: a -> SnocF sig a
  Snoc :: SnocF sig a -> (a -> sig b)
       -> SnocF sig b

reverseF :: SnocF sig a -> ListF sig a
reverseF xs = go xs Ret where
  go :: SnocF sig a -> (a -> ListF sig b) 
     -> ListF sig b
  go (Ret' x) k    = k x
  go (Snoc sx x) k = go sx (\a -> Cons (x a) k)


-- Bankers' queue
--------------------------

data QueueF sig a where
  Q :: Int -> ListF sig a 
    -> Int -> (a -> SnocF sig b)
    -> QueueF sig b

retQ :: a -> QueueF sig a
retQ a = q 0 (Ret a) 0 Ret' 

snoc :: QueueF sig a -> (a -> sig b)
     -> QueueF sig b
snoc (Q lenf f lenr r) k = 
  q lenf f (lenr + 1) (\x -> Snoc (r x) k)

q :: Int -> ListF sig a 
  -> Int -> (a -> SnocF sig b)
  -> QueueF sig b
q lenf f lenr r 
  | lenr <= lenf  = Q lenf f lenr r
  | otherwise     = Q (lenf + lenr) 
      (f >>= (reverseF . r)) 0 Ret'


matchQ :: QueueF sig a 
       -> (forall b. b -> d b)
       -> (forall b c. sig c -> (c -> QueueF sig b) -> d b)
      -> d a
matchQ (Q lenf (Ret b) lenr r) e _  
  = case r b of 
     Ret' a -> e a
     _      -> error "Invariant violation"

matchQ (Q lenf (Cons x xs) lenr r) _ f
  = f x (\b -> q (lenf - 1) (xs b) lenr r)


-- Catenable lists for free monads
----------------------------------

data CListF (sig :: * -> *) (a :: *) where
  E :: a -> CListF sig a
  C :: sig b 
    -> (b -> QueueF (CListF sig) a) 
    -> CListF sig a

inj :: sig x -> CListF sig x
inj x = C x retQ

instance Monad (CListF sig) where
  return = E

  (>>=) :: CListF sig a 
        -> (a -> CListF sig b) 
        -> CListF sig b
  E a    >>= ys = ys a
  C x xs >>= ys = 
    C x (\b -> snoc (xs b) ys)

instance Functor (CListF sig) where
  fmap = liftM

instance Applicative (CListF sig) where
  pure = return
  (<*>) = ap

consC :: sig a -> (a -> CListF sig b) -> CListF sig b
consC x xs = inj x >>= xs

snocC :: CListF sig a -> (a -> sig b) -> CListF sig b
snocC xs x = xs >>= (inj . x)

matchC :: CListF sig a 
       -> (a -> d)
       -> (forall b.  sig b -> 
             (b -> CListF sig a) -> d)
       -> d
matchC (E a)     e _ = e a
matchC (C x xss) _ f = f x (concat . xss)

concat :: QueueF (CListF sig) a 
       -> CListF sig a
concat q = matchQ q E
  (\xs xss -> xs >>= concat . xss)



-- Some simple tests
--------------------------

data State s a = Get (s -> a) | Put s a
  deriving Functor

class Monad m => MonadState m s | m -> s where
  get :: m s
  put :: s -> m ()

instance MonadState (CListF (State s)) s where
  get :: CListF (State s) s
  get = inj (Get id)
  
  put :: s -> CListF (State s) ()
  put s = inj (Put s ())

instance MonadState (ListF (State s)) s where
  get = Cons (Get id) Ret
  put s = Cons (Put s ()) Ret

incr :: MonadState m Int => m Int
incr = do i <- get
          put (i+1)
          return i

handleSt :: CListF (State s) a -> s -> a
handleSt p = matchC p (\a s -> a) hdl 
  where 
    hdl (Get x) k s = handleSt (k (x s)) s
    hdl (Put s' x) k s = handleSt (k x) s'

handleSt' :: ListF (State s) a -> s -> a
handleSt' p = case p of
  (Ret a) -> \s -> a
  (Cons f k) -> hdl f k
  where
   hdl (Get x) k s = handleSt' (k (x s)) s
   hdl (Put s' x) k s = handleSt' (k x) s'

-- Basic correctness check
test0 = handleSt (incr >> incr >> (incr >> incr) >> get) 0 
  -- test0 == 4

-- CListF should be much faster than ListF for left associated computations
incrN :: MonadState m Int => Int -> m Int
incrN 0 = return 0
incrN n = incrN (n-1) >> incr 
  -- This is deliberately associated in the way

test1 = handleSt (incrN 10000 >> get) 0
-- This should be 10000 computed in several seconds

test1' = handleSt' (incrN 10000 >> get) 0 
-- This should take a lot of time


-- CListF supports pattern matching 
test2 = (go 10 (incrN 10000)) == "GPGPGPGPGP"
  where
    go 0 p = []
    go n p = matchC p
      (\_ -> []) 
      (\op k -> case op of
        (Put _ a) -> 
          ('P' : (go (n - 1) (k a)))
        (Get a) ->
          ('G' : (go (n - 1) (k (a 0)))))
