-- Trees with branching parametrised
-- by a functor `sig`
data Free (sig :: * -> *) a where
  Var  :: a -> Free sig a
  Cons :: sig (Free sig a) -> Fee sig a

-- Lambda terms using higher-order 
-- abstract syntax (HOAS)
data Lam where
  Var :: Int -> Lam
  App :: Lam -> Lam -> Lam
  Abs :: (Int -> Lam) -> Lam

-- Church numeral of 2
c2 :: Lam
c2 = Abs (\f -> Abs (\x ->
  App (Var f) (App (Var f) (Var x))))

-- Lam is a special case of Free
--------------------------------
data LamS x = App' x x | Abs' (Int -> x)

to   :: Free LamS Int -> Lam
from :: Lam -> Free LamS Int
(>>=) :: Free sig a -> (a -> Free sig b)
      -> Free sig b

-- Junk terms in Lam can be ruled out
-- using *parametric HOAS*
j :: Lam
j = Abs (\f -> Var 100)

data LamS p x = App' x x | Abs' (p -> x)

type Lam = forall p . Free (LamS p)
