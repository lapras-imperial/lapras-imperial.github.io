{-# LANGUAGE NoImplicitPrelude #-}
module Queue where

import Prelude hiding ((++), length, repeat, reverse)
import Time
import List (List (..), (++))
import SnocList (SnocList (..), reverse)

-- Section 6.3 of Okasaki's book
data Queue a where
  Q :: Int -> List a        -- front
    -> Int -> SnocList a    -- rear
    -> Queue a
  -- Invariant of `Q lenf f lenr r`
  --   lenf is the length of f
  --   lenr is the length of r
  --   lenf >= lenr

nil :: Queue a
nil = Q 0 Nil 0 Lin

cons :: a -> Queue a -> Queue a
cons x (Q lenf f lenr r) =
  Q (1 + lenf) (Cons x f) lenr r

-- amortised O(1)
snoc :: Queue a -> a -> Queue a
snoc (Q lenf f lenr r) x =
  q lenf f (lenr + 1) (Snoc r x)

q :: Int -> List a 
  -> Int -> SnocList a -> Queue a
q lenf f lenr r
  | lenf >= lenr = Q lenf f lenr r
  | otherwise    = 
    Q (lenf + lenr) (f ++ reverse r)
            0       Lin

match :: Queue a
      -> b
      -> (a -> Queue a -> b)
      -> b
match (Q _ Nil _ _) e _ = e
match (Q lenf (Cons x xs) lenr r) _ f =
  f x (q (lenf - 1) xs lenr r)

repeat :: Int -> a -> Queue a
repeat 0 x = nil
repeat n x = snoc (repeat (n - 1) x)  x

repeat' :: Int -> a -> Queue a
repeat' 0 x = nil
repeat' n x = cons x (repeat' (n - 1) x)

length :: Queue a -> Int
length xs = match xs
              0 (\_ n -> 1 + length n)

test1 = time $ 
  length (repeat 10000 'a')

test2 = time $
  length (repeat' 10000 'a')
