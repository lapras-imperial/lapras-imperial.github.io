{-# LANGUAGE GADTs, RankNTypes, TypeOperators, ScopedTypeVariables, KindSignatures, DeriveFunctor, BangPatterns #-}
{-# LANGUAGE FlexibleInstances, FlexibleContexts, MultiParamTypeClasses, FunctionalDependencies, InstanceSigs #-}

-- One possible reason that FastFree.hs is slow is that the monoidal product
--   (f . g) x = exists y. (f y, y -> g x)
-- has a function in the second binder, and functions are not memoized by
-- Haskell, which may destroys the lazy structure in Okasaki's algorithm.
-- Therefore this file (together with LamPHOASMem.hs) tries to memoize functions
-- in the data structure. However, it seems only the memoization in linkAll matters
-- in the test cases.

module FastFreeMem where

import Prelude hiding (head, tail)
import Control.Monad
import Debug.Trace
import Data.IORef
import System.IO.Unsafe
import GHC.Base (noinline)
--import qualified Data.HashTable.IO as H
--
--type HashTable k v = H.CuckooHashTable k v

class Memoizable a where
  memoize :: (a -> b) -> (a -> b)

instance Memoizable Bool where
  memoize f = f
  -- memoize f = \x -> if x then ft else ff where
  --   ff = f False
  --   ft = f True

instance Memoizable Int where
  memoize :: forall b. (Int -> b) -> (Int -> b)
  memoize f = 
    let t :: IORef [(Int, b)]
        t = noinline (unsafePerformIO (newIORef []))
    in \x -> unsafePerformIO $ 
          do h <- readIORef t
             let r = lookup x h 
             case r of
               Nothing -> let v = f x
                          in do writeIORef t ((x, v):h)
                              --  print ("miss " ++ show x)
                                return v
               Just v -> --do print ("hit " ++ show x); return v
                          return v

type M a = Memoizable a
type M2 a b = (Memoizable a, Memoizable b)

class MonadM m where
  returnM :: M a => a -> m a
  bindM :: M2 a b => m a -> (a -> m b) -> m b

data Free sig a where
  Ret  :: M a => a -> Free sig a
  Cons :: M2 a b => sig a -> (a -> Free sig b) -> Free sig b

instance MonadM (Free sig) where
  returnM = Ret

  bindM (Ret a)     k = k a
  -- bindM (Cons x xs) k = Cons x (memoize (\a -> xs a `bindM` k))
  bindM (Cons x xs) k = Cons x (\a -> xs a `bindM` k)

matchF :: M a
       => Free sig a 
       -> (a -> d)
       -> (forall b . M b => sig b -> (b -> Free sig a) -> d)
       -> d
matchF (Ret a) ret _      = ret a
matchF (Cons x xs) _ cons = cons x xs

-- Snoc lists
---------------------------

data FreeSnoc sig a where
  Ret' :: M a => a -> FreeSnoc sig a
  Snoc :: M2 a b => FreeSnoc sig a -> (a -> sig b) -> FreeSnoc sig b

reverseF :: M a => FreeSnoc sig a -> Free sig a
reverseF xs = go xs Ret where
  go :: M2 a b => FreeSnoc sig a -> (a -> Free sig b) -> Free sig b
  go (Ret' x) k    = k x
  --go (Snoc sx x) k = go sx (memoize (\a -> Cons (x a) k))
  go (Snoc sx x) k = go sx (\a -> Cons (x a) k)


-- Bankers' queue
--------------------------

data QueueF sig a where
  Q :: M2 a b => !Int -> Free sig a -> !Int -> (a -> FreeSnoc sig b) -> QueueF sig b
  -- Invariants : for all |Q lenf f lenr r|, 
  --   |lenf| is the depth for |f|, 
  --   |lenr| is the depth for |r a| for all |a|,
  --   and |lenr <= lenf|.

q :: M2 a b => Int -> Free sig a -> Int -> (a -> FreeSnoc sig b) -> QueueF sig b
q lenf f lenr r 
  | lenr <= lenf  = Q lenf f lenr r
--  | otherwise     = Q (lenf + lenr) (f `bindM` memoize (\b -> reverseF (r b))) 0 Ret'
  | otherwise     = Q (lenf + lenr) (f `bindM` (\b -> reverseF (r b))) 0 Ret'


retQ :: M a => a -> QueueF sig a
retQ a = q 0 (Ret a) 0 Ret' 

snoc :: M2 a b => QueueF sig a -> (a -> sig b) -> QueueF sig b
--snoc (Q lenf f lenr r) k = q lenf f (lenr + 1) (memoize (\x -> Snoc (r x) k))
snoc (Q lenf f lenr r) k = q lenf f (lenr + 1) (\x -> Snoc (r x) k)

match :: M a => QueueF sig a 
      -> (a -> d a)
      -> (forall b . M b => sig b -> (b -> QueueF sig a) -> d a)
      -> d a
match (Q lenf (Ret b) lenr r) ret _  = case r b of Ret' a -> ret a
                                                   _      -> error "Invariant violation"

--match (Q lenf (Cons x xs) lenr r) _ cons = cons x (memoize (\b -> q (lenf - 1) (xs b) lenr r))
match (Q lenf (Cons x xs) lenr r) _ cons = cons x (\b -> q (lenf - 1) (xs b) lenr r)


-- Catenable lists for free monads
-------------------------------

data CListF (sig :: * -> *) (a :: *) where
  E :: M a => a -> CListF sig a
  C :: M2 a b => sig b -> (b -> QueueF (CListF sig) a) -> CListF sig a

-- Technical note:
-- In the original algorithm from Okasaki in CatList.hs, the QueueF in CListF only stores
-- non-E CListF, but we can't decide if a |a -> CListF sig a| is E or not, so here
-- we do allow QueueF to store E. Thus the |link| function and |++| function in CatList.hs
-- become the same one here.

-- Concatenation is essentially snoc
append :: M2 a b => CListF sig a -> (a -> CListF sig b) -> CListF sig b
append (E a)    ys = ys a
--append (C x xs) ys = C x (memoize (\b -> snoc (xs b) ys))
append (C x xs) ys = C x (\b -> snoc (xs b) ys)

inj :: M a => sig a -> CListF sig a
inj x = C x retQ

consC :: M2 a b => sig a -> (a -> CListF sig b) -> CListF sig b
consC x xs = append (inj x) xs

snocC :: M2 a b => CListF sig a -> (a -> sig b) -> CListF sig b
--snocC xs x = append xs (memoize (\a -> inj (x a)))
snocC xs x = append xs (\a -> inj (x a))

matchC :: M a 
       => CListF sig a 
       -> (a -> d)
       -> (forall b . M b => sig b -> (b -> CListF sig a) -> d)
       -> d
matchC (E a) ret _     = ret a
--matchC (C x xs) _ cons = cons x (memoize (\b -> linkAll (xs b))) 
matchC (C x xs) _ cons = cons x (\b -> linkAll (xs b)) 

-- This is a kind of concat
linkAll :: M a => QueueF (CListF sig) a -> CListF sig a
linkAll q = match q E (\xs xss -> xs `append` memoize (\b -> linkAll (xss b)))
                                           -- ^^^^^^^
                                           --    |
                                           --  This seems the only useful memoize


-- CListF is a representation of Free supporting amortised O(1)-time
-- pattern matching and >>=.
instance MonadM (CListF sig) where
  returnM = E
  bindM  = append
