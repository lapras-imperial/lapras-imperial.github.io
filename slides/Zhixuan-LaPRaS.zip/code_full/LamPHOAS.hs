{-# LANGUAGE GADTs, RankNTypes, TypeApplications, TypeOperators, ScopedTypeVariables, KindSignatures, DeriveFunctor #-}
{-# LANGUAGE FlexibleInstances, FlexibleContexts, MultiParamTypeClasses, FunctionalDependencies, InstanceSigs #-}

-- Using FastFree to implement a normaliser of lambda calculus based on
-- parametric higher-order abstract syntax

import FastFree
import Data.Bool (bool)

-- for names we use an arbitrary type `a` that can be compared 
-- and has a stream of distinct elements
class (Eq a) => Atom a where
  ns :: [a]
  -- and we require a name can be printed as an identifier
  showName :: a -> String

instance Atom Int where
  ns = [1..]
  showName n = "x" ++ show n

data LamS a x = App x x | Abs (a -> x)

type LamP a = CListF (LamS a) a

type Lam = forall a. Atom a => LamP a

instance Atom a => Show (LamP a) where
  show t = fst (go ns t) where
    go :: [a] -> LamP a -> (String, [a])
    go ns t = matchC t (\a -> (showName a, ns)) f where
      f :: LamS a b -> (b -> LamP a) -> (String, [a])
      f (App fun opr) k = let (s1, ns') = go ns (k fun)
                              (s2, ns'') = go ns' (k opr)
                          in (s1 ++ " " ++ s2, ns'')
      f (Abs body) k = let (n:ns') = ns 
                           (s, ns'') = go ns' (k (body n))
                       in ("(λ " ++ showName n ++ ". " ++  s ++ ")", ns'')

printLam :: Lam -> IO ()
printLam t = print (t :: LamP Int)

app :: LamP a -> LamP a -> LamP a
app t1 t2 = consC (App False True) (bool t1 t2)

lam :: (a -> LamP a) -> LamP a
lam t = consC (Abs id) t

var :: a -> LamP a
var = return

t1 :: Lam
t1 = app (lam (\x -> var x `app` var x)) (lam (\x -> var x))

-- replaces every occurrence of x in t with m
subst :: Atom a => LamP a -> a -> LamP a -> LamP a
subst t x m = t >>= (\y -> if y == x then m else var y)

-- full normalisation in the applicative order
norm :: Lam -> Lam
norm t = fst (go ns t) where
  go :: forall a. Atom a => [a] -> LamP a -> (LamP a, [a])
  go ns t = matchC t (\a -> (return a, ns)) f where
    f :: forall b. LamS a b -> (b -> LamP a) -> (LamP a, [a])
    f (Abs body)  k = 
      let (n:ns')      = ns
          (body',ns'') = go ns' (k (body n))
      in (lam (\a -> subst body' n (var a)), ns'')

    f (App t1 t2) k = 
      let (t1', ns')  = go ns (k t1)
          (t2', ns'') = go ns' (k t2)

          g :: forall b. LamS a b -> (b -> LamP a) -> (LamP a, [a])
          g (Abs b) k2 = let (n:ns''') = ns''
                         in go ns''' (subst (k2 (b n)) n t2')
          g _       k2 = (app t1' t2', ns'')
      in  matchC t1' (\a -> (app t1' t2', ns'')) g 

t2 :: Lam
t2 = lam (\f -> var f `app` var f)
       `app`
       lam (\x -> lam (\y -> var x `app` var y))

-- Church numeral of 3
c3 :: Lam
c3 = lam (\f -> lam (\x -> var f `app` (var f `app` (var f `app` var x))))

infixl 4 `app` 
cadd :: Lam
cadd = lam (\n -> lam (\m -> lam (\f -> lam (\x -> 
          var n `app` var f 
            `app` (var m `app` var f `app` var x)))))

t3 :: Lam
t3 = cadd `app` c3 `app` c3

-- printLam (norm t3)
-- (λ x1. (λ x2. x1 x1 x1 x1 x1 x1 x2))

cmul :: Lam
cmul = lam (\n -> lam (\m -> lam (\f -> lam (\x -> 
         var n `app` (var m `app` var f) `app` var x))))

t4 :: Lam
t4 = cmul `app` t3 `app` t3

t5 :: Lam
t5 = cmul `app` t4 `app` t4

t6 :: Lam
t6 = cmul `app` t4 `app` t5

main = print (length (show (norm t6 :: LamP Int)))
