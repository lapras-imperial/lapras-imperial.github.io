{-# LANGUAGE NoImplicitPrelude #-}
module CList where

import Prelude hiding ((++), length, repeat, reverse, concat)
import Time
import Queue (Queue)
import qualified Queue as Q
import List (List (..))
import SnocList (SnocList (..))

-- Section 10.2 of Okasaki's book
data CList a where
  E :: CList a
  C :: a -> Queue (CList a) -> CList a

singleton :: a -> CList a
singleton x = C x Q.nil

(++) :: CList a -> CList a -> CList a
xs ++ E  = xs
E  ++ ys = ys
(C x xss) ++ ys = C x (Q.snoc xss ys)

cons :: a -> CList a -> CList a
cons x xs = singleton x ++ xs

snoc :: CList a -> a -> CList a
snoc xs x = xs ++ singleton x

match :: CList a
      -> b
      -> (a -> CList a -> b)
      -> b
match E e _ = e
match (C x xss) e f = f x (concat xss)

concat :: Queue (CList a) -> CList a
concat xss = Q.match xss E 
  (\xs xss' -> xs ++ concat xss')

repeat :: Int -> a -> CList a
repeat 0 x = E
repeat n x = snoc (repeat (n - 1) x)  x

length :: CList a -> Int
length xs = match xs
              0 (\_ n -> 1 + length n)

test1 = time $ 
  length (repeat 10000 'a')
