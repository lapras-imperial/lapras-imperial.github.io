module Time where

import Data.Time.Clock

time :: Show a => a -> IO ()
time action = do
  start <- getCurrentTime
  print action
  end <- getCurrentTime
  let duration = diffUTCTime end start
  putStrLn $ "took " ++ show duration
