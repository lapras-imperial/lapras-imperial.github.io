{-# LANGUAGE GADTs, RankNTypes, TypeOperators, ScopedTypeVariables, KindSignatures #-}

module FastApp where

import Prelude hiding (head, tail)
import Control.Applicative

-- We do the translation:
--
-- types A   ↦  functors F 
--
-- functions A -> B   
--   ↦
-- polymorphic functions 
--   (forall x. F x -> G x)
--
-- cartesian product (A, B)
--   ↦
-- Day tensor product
--   exists b c. (F c, G b, c -> b -> a)

data FreeA sig a where
  Pure :: a -> FreeA sig a
  Ap   :: sig b -> FreeA sig c 
       -> (b -> c -> a)
       -> FreeA sig a

instance Functor (FreeA sig) where
  fmap f (Pure x)    = Pure (f x)
  fmap f (Ap x xs k) = Ap x xs (\b c -> f (k b c))

instance Applicative (FreeA sig) where
  pure = Pure
  (Pure k)    <*> ys = fmap k ys
  (Ap x xs k) <*> ys = Ap x (fmap (\c a b' -> k b' c a) xs <*> ys) (flip ($))

reverseA :: forall sig a. FreeA sig a -> FreeA sig a
reverseA xs = go xs (Pure id) where
  go :: forall d. FreeA sig d
     -> FreeA sig (d -> a) 
     -> FreeA sig a
  go (Pure e)    ys = fmap ($ e) ys
  go (Ap x xs k) ys = go xs (Ap x ys (\b d2a c -> d2a (k b c)))

data QueueA sig a where
  Q :: Int -> FreeA sig b 
    -> Int -> FreeA sig c
    -> (b -> c -> a) 
    -> QueueA sig a

-- Smart constructor maintaining the invariant:
q :: Int -> FreeA sig b -> Int -> FreeA sig c -> (b -> c -> a) -> QueueA sig a
q lenf f lenr r k
  | lenr <= lenf  = Q lenf f lenr r k
  | otherwise     = Q (lenf + lenr) (liftA2 k f (reverseA r)) 0 (Pure ()) (\x _ -> x)


instance Functor (QueueA sig) where
  fmap g (Q lenf f lenr r k) 
    = Q lenf f lenr r (\b c -> g (k b c))

pureQ :: a -> QueueA sig a
pureQ x = q 0 (Pure x) 0 (Pure ()) (\x _ -> x)

isPure :: QueueA sig a -> Maybe a
isPure (Q _ (Pure b) _ (Pure c) k) = Just (k b c)
isPure _                           = Nothing

snoc :: QueueA sig b -> sig c -> (b -> c -> a) -> QueueA sig a
snoc (Q lenf f lenr r k) x k' = q lenf f (lenr + 1) (Ap x r (\c' c b -> k' (k b c) c')) (flip ($))

match :: QueueA sig a 
      -> (a -> d a)
      -> (forall b c. sig b -> QueueA sig c -> (b -> c -> a) -> d a)
      -> d a
match (Q _    (Pure x)     _   (Pure y)    k)  f _ = f (k x y)
match (Q lenf (Ap x xs k) lenr ys          k') _ g = g x (q (lenf - 1) xs lenr ys (\c c' b -> k' (k b c) c')) (flip ($))


-- Now that we have a queue, we can do catenable lists using Okasaki's
-- bootstrapping technique.

data CListA (sig :: * -> *) (a :: *) where
  E :: a -> CListA sig a
  C :: sig b -> QueueA (CListA sig) c -> (b -> c -> a) -> CListA sig a

instance Functor (CListA sig) where
  fmap g (E e) = E (g e)
  fmap g (C x xs k) = C x xs (\b c -> g (k b c))

link :: CListA sig b -> CListA sig c -> (b -> c -> a) -> CListA sig a
link (C x q k) s k' = C x (snoc q s (\c c' b -> k' (k b c) c')) (flip ($))

pureC :: a -> CListA sig a
pureC e = E e

isPureC :: CListA sig a -> Maybe a
isPureC (E a) = Just a
isPureC _     = Nothing

append :: CListA sig b -> CListA sig c -> (b -> c -> a) -> CListA sig a
append xs (E c) k = fmap (\b -> k b c) xs
append (E b) ys k = fmap (\c -> k b c) ys
append xs ys    k = link xs ys k

inj :: sig a -> CListA sig a
inj x = C x (pureQ ()) (\x () -> x)

consC :: sig b -> CListA sig c -> (b -> c -> a) -> CListA sig a
consC x xs k = append (inj x) xs k

snocC :: CListA sig b -> sig c -> (b -> c -> a) -> CListA sig a
snocC xs x k = append xs (inj x) k

matchC :: CListA sig a 
       -> (a -> d a)
       -> (forall b c. sig b -> CListA sig c -> (b -> c -> a) -> d a)
       -> d a
matchC (E e) f _     = f e
matchC (C x q k) _ g = g x tail k where
  tail = case isPure q of
    Just c -> E c
    _      -> linkAll q

linkAll :: QueueA (CListA sig) a -> CListA sig a
linkAll q = 
  match q (error "This should be non-empty") 
          (\t q' k -> case isPure q' of 
                        (Just c) -> fmap (\b -> k b c) t
                        _        -> link t (linkAll q') k)

-- Finally! We have an efficient free applicative supporting both
--   amortised O(1)-time <*> and pattern matching!
instance Applicative (CListA sig) where
  pure = pureC
  xs <*> ys = append xs ys (\f a -> f a)


runAp :: Applicative g => (forall x. f x -> g x) -> CListA f a -> g a
runAp h xxs = matchC xxs pure (\x xs k -> pure k <*> h x <*> runAp h xs)

runAp_ :: Monoid m => (forall a. f a -> m) -> CListA f b -> m
runAp_ f = getConst . runAp (Const . f)

liftAp :: sig x -> CListA sig x
liftAp = inj
