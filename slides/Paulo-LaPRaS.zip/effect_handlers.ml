open Printf
open Effect
open Effect.Deep

module Shallow : sig
  include (module type of Effect.Shallow)

  val continue : ('a, 'b) continuation -> 'a -> 'b

  val match_with : ('c -> 'a) -> 'c -> ('a, 'b) handler -> 'b

end = struct
  include Effect.Shallow

  let continue k x =
    continue_with k x
      { retc = Fun.id;
        exnc = raise;
        effc = fun _ -> None;
      }

  let match_with f x h =
    continue_with (fiber f) x h
end


(* ------------------------------------------------------------------------- *)
(* Effect handlers. *)

(* Operations:
   1. Effect declaration.
   2. Performing an effect.
   3. Handling an effect.
*)

(* 1 - Effect declaration. *)

type _ Effect.t += Division_by_zero : int Effect.t

(* 2 - Performing an effect. *)

let ( / ) x y = if y = 0 then perform Division_by_zero else Int.div x y

(* 3 - Handling an effect. *)

let _ =
  match 1 + (2 / 0) + (3 / 0) with
  | effect Division_by_zero, k ->
      continue k 1
  | y ->
      y

(* Comparison with exceptions. *)

exception Division_by_zero

let ( / ) x y = if y = 0 then raise Division_by_zero else Int.div x y

let _ =
  match 1 + (2 / 0) + (3 / 0) with
  | exception Division_by_zero ->
      0
  | y ->
      y


(* ------------------------------------------------------------------------- *)
(* Shallow VS Deep. *)

type _ Effect.t += E : unit -> unit t

(* Deep handler: computation exits gracefully. *)
let _ =
  let f() = perform (E()) in
  match f(); f() with
  | effect E (), k ->
      continue k ()
  | y ->
      y

(* Shallow handler: computation ends abruptly with an unhandled effect. *)
let _ =
  let open Shallow in
  let f() = perform (E()) in
  match_with (fun _ -> f(); f()) ()
    { retc = Fun.id;
      exnc = raise;
      effc = fun (type b) (eff : b Effect.t) ->
        match eff with
        | E () -> Some (fun (k : (b, _) continuation) ->
            continue k ()
          )
        | _ -> None
    }


(* ------------------------------------------------------------------------- *)
(* Examples. *)

(* State. *)

type _ Effect.t += Get : unit -> int t
type _ Effect.t += Set : int -> unit t
type _ Effect.t += Print : unit t

let get() = perform (Get())
let set y = perform (Set y)
let print() = perform Print

let countdown() =
  set 10;
  while 0 < get() do
    print();
    set (get() - 1)
  done

let run main =
  let x = ref 0 in
  match main() with
  | effect Get (), k -> continue k !x
  | effect Set y, k -> x := y; continue k ()
  | effect Print, k -> printf "%d\n" !x; continue k ()
  | () -> ()

let _ = run countdown

(* Modular interpretation of effects. *)

let collect main =
  let x = ref 0 in
  match main() with
  | effect Get (), k -> continue k !x
  | effect Set y, k -> x := y; continue k ()
  | effect Print, k -> let x' = !x in x' :: continue k ()
  | () -> []

let _ = collect countdown

let check main ~expected:xs =
  let x = ref 0 and i = ref 0 and xs = Array.of_list xs in
  match main() with
  | effect Get (), k -> continue k !x
  | effect Set y, k -> x := y; continue k ()
  | effect Print, k ->
      if !i < Array.length xs && xs.(!i) = !x then begin
        incr i;
        continue k ()
      end else
        false
  | () ->
      !i = Array.length xs

let _ = check countdown ~expected:(collect countdown)
let _ = check countdown ~expected:[11]
let _ = check countdown ~expected:[10; 9; 8; 7; 3]


(* ------------------------------------------------------------------------- *)
(* Advanced example - Asynchronous computation. *)

(* Asynchronous computation is a paradigm where a scheduler manages multiple
     ongoing tasks and schedules exactly one task to be executed at a time.
*)


(* Fork. *)

(* High-level idea: The operation "fork task" starts the execution of "task"
     thus interrupting the currently running which is scheduled for later.
     When a task terminates, the scheduler runs the task that has been paused
     the longest.

   Note: This is just one possible scheduling approach.
*)

module Fork : sig

  val fork : (unit -> unit) -> unit

  val run : (unit -> unit) -> unit

end = struct

  type _ Effect.t += Fork : (unit -> unit) -> unit t

  let fork f = perform (Fork f)

  let run main =
    let open Queue in
    let tasks = create() in
    let next() = if not (is_empty tasks) then (take tasks) () in
    let rec run task =
      match task() with
      | effect Fork task', k ->
          add (continue k) tasks;
          run task'
      | () ->
          next()
    in
    run main

end

(* Example. *)
let _ =
  let open Fork in
  let main() =
    fork (fun () ->
      printf "Step 1 - Prepare for trouble\n";
      fork (fun () -> printf "Step 2 - Make it double\n")
    );

  in
  run main


(* Async & Await. *)

(* Asynchronous computation with promises (≈ fork + join). *)

(* High-level idea: The operation operation "async task" is similar to
     "fork task" with the difference that it returns a promise "p" that
     can be used to wait for the result of "task" through the operation
     "await p".

   Implementation. The main difference is the addition of the type
     "'a promise" which is implemented as a mutable field storing either
     the result of the task to which it is associated or a list of paused
     threads waiting for this result.
*)

module Async : sig

  type 'a promise

  val async : (unit -> 'a) -> 'a promise
  val await : 'a promise -> 'a

  val run : (unit -> 'a) -> 'a

end = struct

  type 'a status =
    | Waiting of ('a -> unit) list
    | Done of 'a

  type 'a promise = ('a status) ref

  let get_done_val p =
    match !p with
    | Waiting _ -> assert false
    | Done y -> y

  let get_waiting_list p =
    match !p with
    | Waiting ks -> ks
    | Done _ -> assert false

  type _ Effect.t += Async : (unit -> 'a) -> ('a promise) t
  type _ Effect.t += Await : 'a promise -> 'a t

  let async task = perform (Async task)
  let await p = perform (Await p)

  let make_promise() = ref (Waiting [])

  let run main =
    let ready = Queue.create() in
    let next() = if not (Queue.is_empty ready) then (Queue.take ready) () in
    let rec fulfil : type a. a promise -> (unit -> a) -> unit = fun p task ->
      match task() with
      | effect Async task', k ->
          let p' = make_promise() in
          Queue.add (fun () -> continue k p') ready;
          fulfil p' task'
      | effect Await p', k ->
          begin match !p' with
          | Done v -> continue k v
          | Waiting ks ->
              p' := Waiting (continue k :: ks);
              next()
          end
      | y ->
          let ks = get_waiting_list p in
          List.iter (fun k -> Queue.add (fun () -> k y) ready) ks;
          p := Done y;
          next()
    in    
    let p = make_promise() in
    fulfil p main;
    get_done_val p

end

(* Example. *)
let _ =
  let open Async in
  let main() =
    let p1 = async (fun () -> 1) in
    let p2 = async (fun () ->
      let p3 = async (fun () -> async (fun () -> 3)) in
      2 + await (await p3)
    )
    in
    await p1 + await p2
  in
  run main


(* ------------------------------------------------------------------------- *)
(* Advanced example - Control inversion. *)

(* Control inversion is a programming technique to transform
     an _iteration method_ into a _lazy sequence_.
*)

(* Iteration method: eagerly applies an input function
     to the elements of a collection.

     type 'a iter = ('a -> unit) -> unit

   Examples.

   - Collection: xs

       fun f -> List.iter f xs

   - Collection: {'L', 'a', 'P', 'R', 'a', 'S'}

       fun f -> begin f 'L'; f 'a'; f 'P'; f 'R'; f 'a'; f 'S' end

*)

(* Lazy sequences (a.k.a. Haskell's lists): a lazy sequence produces
     elements on demand.

     type 'a node = Nil | Cons of 'a * 'a seq
     and 'a seq = unit -> 'a node

   Examples.

   - let rec ints n = Seq.Cons (n, fun () -> ints (n + 1))
*)

(* High-level idea: to use an effect to stop the iteration
     which we resume on demand.
*)

module Yield : sig

  type 'a iter = ('a -> unit) -> unit

  val invert : 'a iter -> 'a Seq.t

end = struct

  type 'a iter = ('a -> unit) -> unit

  let invert (type a) (iter : a iter) : a Seq.t = fun () ->
    let open struct type _ Effect.t += Yield : a -> unit t end in
    let yield x = perform (Yield x) in
    match iter yield with
    | effect Yield x, k -> Seq.Cons (x, continue k)
    | () -> Seq.Nil

end


(* Python-like definition of a stream of integers. *)
let ints n = Yield.invert (fun yield ->
    let x = ref n in
    while true do
      yield !x;
      x := !x + 1
    done
  )

let _ = List.of_seq (Seq.take 10 (ints 0))


(* Same fringe problem. *)
type tree = Leaf of int | Node of tree list

(* Implementation without effects. *)
let same_fringe_without_effects t1 t2 =
  let fringe t =
    let rec fringe is = function
      | Leaf i -> is @ [i]
      | Node ts -> List.fold_left (fun is t -> fringe is t) is ts
    in
    fringe [] t
  in

  let fringe1 = fringe t1 and fringe2 = fringe t2 in

  List.(length fringe1 = length fringe2)
  && List.for_all2 (=) fringe1 fringe2

(* Implementation with effects. *)
let same_fringe t1 t2 =
  let rec tree_iter f = function
    | Leaf i -> f i
    | Node ts -> List.iter (tree_iter f) ts
  in

  let fringe t = Yield.invert (fun yield -> tree_iter yield t) in

  Seq.equal (=) (fringe t1) (fringe t2)

(* simpler code. *)

(* better efficiency in space (no need to store the elements)
     and time (algorithm exits as soon as a mismatch is found). *)

(*  .
   /|\
  0 1 2
*)

let t1 = Node [Leaf 0; Leaf 1; Leaf 2]

(*  .
   / \
  |  /\
  0 1  |
       2
*)

let t2 = Node [Node [Leaf 0]; Node [Leaf 1; Node [Leaf 2]]]

(*  .
   / \
  0  /|\
    1 2 3
*)

let t3 = Node [Leaf 0; Node [Leaf 1; Leaf 2; Leaf 3]]

let _ = same_fringe t1 t2
let _ = same_fringe t1 t3
let _ = same_fringe t2 t3
